import _sequelize from "sequelize";
const DataTypes = _sequelize.DataTypes;
import _doctor from  "./doctor.js";
import _nurse from  "./nurse.js";

export default function initModels(sequelize) {
  const doctor = _doctor.init(sequelize, DataTypes);
  const nurse = _nurse.init(sequelize, DataTypes);

  nurse.belongsTo(doctor, { as: "doctor", foreignKey: "doctorid"});
  doctor.hasMany(nurse, { as: "nurses", foreignKey: "doctorid"});
  doctor.belongsTo(usertable, { as: "user", foreignKey: "userid"});
  usertable.hasMany(doctor, { as: "doctors", foreignKey: "userid"});
  nurse.belongsTo(usertable, { as: "user", foreignKey: "userid"});
  usertable.hasMany(nurse, { as: "nurses", foreignKey: "userid"});
  nurse.belongsTo(ward, { as: "ward", foreignKey: "wardid"});
  ward.hasMany(nurse, { as: "nurses", foreignKey: "wardid"});

  return {
    doctor,
    nurse,
  };
}
