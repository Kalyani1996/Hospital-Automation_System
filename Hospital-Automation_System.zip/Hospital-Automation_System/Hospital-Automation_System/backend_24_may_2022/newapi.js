import express from 'express';
import cors from 'cors';

const PORT =  process.env.PORT || 7011;

// create an instance
const instance = express();
// Add JSON Middleware in HTTP Pipeline
instance.use(express.json());
// do not parse incoming data other than HTTP Request Message Body
instance.use(express.urlencoded({extended:false}));
// configure CORS
instance.use(cors({
    origin: "*",
    methods: "*",
    allowedHeaders: "*"
})); 

// import dataaccess

import DataAccess from './dataaccess/tokenissuer.js'

let ds = new DataAccess();
// lets create REST API
instance.post('/api/login', ds.loginUser);
instance.post('/api/createuser', ds.createNewUser);
instance.post('/api/createward', ds.addWard);
instance.post('/api/createroom', ds.addRoom);
instance.post('/api/admitpatients', ds.admitPatient);
instance.post('/api/observationonpatient', ds.observationOnPatient);
instance.post('/api/recordpatientdetail',ds.recordPatientDetail);
instance.post('/api/generatebill',ds.generateBill);
instance.post('/api/createdoctor',ds.createNewDoctor);


//report api

instance.get('/api/doctorwisepatient',ds.getDoctorWisePatient);
instance.get('/api/getallpatient',ds.getAllAdmittedPatient);
instance.get('/api/wardwisepatient',ds.getWardWisePatient);
instance.get('/api/wardwiseroom',ds.getWardWiseRoom);
instance.get('/api/wardwisenurse',ds.getWardWiseNurse);
instance.get('/api/searchpatient/:id/:wardid/:roomid',ds.searchPatients);
instance.get('/api/observedPatients', ds.getAllObservedPatients);


instance.get('/api/patients', ds.getPatientData);
instance.get('/api/wards', ds.getWardData);
instance.get('/api/rooms', ds.getRoomData);
instance.get('/api/doctors', ds.getDoctorData);





// start listening
instance.listen(PORT, ()=>{
    console.log(`Started on port ${PORT}`);
});