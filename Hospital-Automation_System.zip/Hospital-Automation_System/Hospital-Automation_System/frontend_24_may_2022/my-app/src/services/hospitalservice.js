import axios from 'axios';
class HospitalService{
    constructor(){
        this.url = 'http://localhost:7011';
    }
    async authData(data){

        let response = await axios.post(`${this.url}/api/login`,data,{
            headers:{
                'Content-Type': 'application/json'
            }
        });
        return response;
    }
    async postData(data,token){
        let response = await axios.post(`${this.url}/api/createuser`,data,{
            headers:{
                'Content-Type': 'application/json',
                'Authorization': 'Bearer '+token
            }
        });
        return response;
    }
    async postWardData(data,token){
        let response = await axios.post(`${this.url}/api/createward
        `,data,{
            headers:{
                'Content-Type': 'application/json',
                'Authorization': 'Bearer '+token
            }
        });
        return response;
    }
    async postRoomData(data,token){
        let response = await axios.post(`${this.url}/api/createroom
        `,data,{
            headers:{
                'Content-Type': 'application/json',
                'Authorization': 'Bearer '+token
            }
        });
        return response;
    }
    async postAdmitPatientData(data,token){
        let response = await axios.post(`${this.url}/api/admitpatients
        `,data,{
            headers:{
                'Content-Type': 'application/json',
                'Authorization': 'Bearer '+token
            }
        });
        return response;
    }
    async postDoctorData(data,token){
        let response = await axios.post(`${this.url}/api/createdoctor
        `,data,{
            headers:{
                'Content-Type': 'application/json',
                'Authorization': 'Bearer '+token
            }
        });
        return response;
    }
    async postBillData(data,token){
        let response = await axios.post(`${this.url}/api/generatebill
        `,data,{
            headers:{
                'Content-Type': 'application/json',
                'Authorization': 'Bearer '+token
            }
        });
        return response;
    }
    async postObservationData(data,token){
        let response = await axios.post(`${this.url}/api/observationonpatient
        `,data,{
            headers:{
                'Content-Type': 'application/json',
                'Authorization': 'Bearer '+token
            }
        });
        return response;
    }
    //get records api doctorwise patient
    async getDoctorwiseData(){
        let response = await axios.get(`${this.url}/api/doctorwisepatient`);
        return response;
    }
    
    async getCurrentPatientData(){
        let response = await axios.get(`${this.url}/api/getallpatient`);
        return response;
    }
    async getWardWiseRoomData(){
        let response = await axios.get(`${this.url}/api/wardwiseroom`);
        return response;
    }
    async getWardWisePatient(){
        let response = await axios.get(`${this.url}/api/wardwisepatient`);
        return response;
    }

    async getWardWiseNurse(){
        let response = await axios.get(`${this.url}/api/wardwisenurse`);
        return response;
    }
    
}
export default HospitalService;