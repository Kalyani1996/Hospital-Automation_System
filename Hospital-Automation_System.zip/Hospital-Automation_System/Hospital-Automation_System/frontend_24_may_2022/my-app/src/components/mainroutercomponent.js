import React from 'react';
// Import Router Object Model to define Route Table
import {Router, Routes, Route} from 'react-router-dom';
import CreateUserComponent from './createusercomponent.js';
import LoginComponent from './logincomponent';
import LayoutComponent from './layoutcomponent.js';
import CreateWardComponent from './createwardcomponent.js';
import CreateRoomComponent from './createroomcomponent.js';
import CreateDoctorComponent from './createdoctorcomponent.js';
import CreatePatientComponent from './createpatientcomponent.js';
import CreateBillComponent from './createbillcomponent.js';
import DisplayRecordComponent from './displayrecordcomponent.js';
import DoctorObservationComponent from './doctorobservationcomponent.jsx';
const MainRouterComponent=()=>{
    return(
        <div className='container'>
            {/* <Routes>
                <Route path="/" element={<LayoutComponent/>}>
                    index is a property that represents that this is default UI
                    <Route index element={<ListDepartmentsComponent/>}/>
                    <Route path="/create" element={<CreateDepartmentComponent/>}/>
                    Route with the Route Parameter
                    <Route path="/edit/:deptno" element={<EditDepartmentComponent/>}/>
                    <Route path="/delete/:deptno" element={<DeleteDepartmentComponent/>}/>
                    <Route path="*" element={<NotFoundComponent/>}/>
                </Route>
            </Routes> */}
   
           
            <Routes>
                <Route path="/" element={<LoginComponent/>} />
                <Route path="/generatebill" element={<CreateBillComponent/>} />
                <Route path="/doctorobservation" element={<DoctorObservationComponent/>} />

                 <Route path="/" element={<LayoutComponent/>}>
                    <Route path="/createuser" element={<CreateUserComponent/>} />
                    <Route path="/createward" element={<CreateWardComponent/>} />
                    <Route path="/createroom" element={<CreateRoomComponent/>} />
                    <Route path="/createdoctor" element={<CreateDoctorComponent/>} />
                    <Route path="/createpatient" element={<CreatePatientComponent/>} />
                    {/* <Route path="/getrecords" element={<ListRecordComponent/>} /> */}
                    <Route path="/displayrecords" element={<DisplayRecordComponent/>} />

                    {/* <Route path="/addpatient" element={<ListDepartmentsComponent />} /> */}
                   
                    {/* Route with the Route Parameter */}
                    {/* <Route path="*" element={<NotFoundComponent />} /> */}
                </Route>
            </Routes>
      
        </div>
    );
};
export default MainRouterComponent;