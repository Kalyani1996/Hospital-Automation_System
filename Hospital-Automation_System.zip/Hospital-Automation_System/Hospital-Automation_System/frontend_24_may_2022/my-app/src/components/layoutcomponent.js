import React from 'react';
// Router Object Model
import {Link,Outlet} from 'react-router-dom';

const LayoutComponent=()=>{
  return (
      <div className='container'>
      <h2><center><b>Hospital Automation System</b></center></h2>
          <table className='table table-bordered table-striped'>
              <tbody>
                  <tr>
                      <td>
                          <Link to="/createuser">Create User</Link>
                      </td>
                      <td>
                          <Link to="/createward">Create Ward</Link>
                      </td>
                      <td>
                          <Link to="/createroom">Create Room</Link>
                      </td>
                      <td>
                          <Link to="/createdoctor">Create Doctor</Link>
                      </td>
                      <td>
                          <Link to="/createpatient">Create Patient</Link>
                      </td>
                      {/* <td>
                          <Link to="/generatebill">Create Bill</Link>
                      </td> */}
                      {/* <td>
                          <Link to="/getrecords">Get Records</Link>
                      </td> */}
                      <td>
                          <Link to="/displayrecords">Get Records</Link>
                      </td>
                  </tr>
              </tbody>
          </table>
          <hr/>
          {/* Components will be Mounted Here */}
          <Outlet/>
      </div>
  );
};

export default LayoutComponent;