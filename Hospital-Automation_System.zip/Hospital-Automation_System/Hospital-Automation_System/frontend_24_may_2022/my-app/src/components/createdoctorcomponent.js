import react, { Fragment, useState } from 'react';
import { Link } from 'react-router-dom';
// import SelectComponent from '../reusablecomponents/SelectComponent';
import HospitalService from '../services/hospitalservice';

const CreateDoctorComponent = () => {

    const [user,setUser] = useState({firstname:'',lastname:'',username:'',password:'',emailid:'',mobileno:0,roleid:0,specialization:'',doctorname:'',userid:0})
    //const roles = [{id:3,rolename:"WardBoys"},{id:4,rolename:"Accountant"},{id:6,rolename:"Patient"}];
    const serv = new HospitalService();
    let n = Math.random();
    n = n * 100; 
    let randomId = (Math.floor(n)+1);
    const [message, setMessage] = useState('');
    const handleInputChange = (evt) =>{
        console.log("is it called"+evt.target.value);
        setUser({...user,[evt.target.name]:evt.target.value});
    }
    const clear = () =>{
        setUser({firstname:'',lastname:'',username:'',password:'',emailid:'',mobileno:0,roleid:0,specialization:'',doctorname:'',userid:0});
    }
    const createUser = () =>{
       console.log(localStorage.getItem("mytoken"));
       let mytoken = localStorage.getItem("mytoken");
        const data = {
            id:randomId,
            firstname:user.firstname,
            lastname:user.lastname,
            username:user.username,
            password:user.password,
            emailid:user.emailid,
            mobileno:user.mobileno,
            roleid:5,
            specialization:user.specialization,
            doctorname:user.doctorname,
            userid:randomId
        }
        serv.postDoctorData(data,mytoken).then(            
            (response)=>{setMessage(`${response.data.message}`)
        
        alert("Doctor created succesfully");
    }
        ).catch((error)=>{
            setMessage('Error Occured')
        });
    }
    return(
        <Fragment>
            <h1>Create Doctor</h1>
            <div className='form-group'>
           <label htmlFor="">First Name</label>
           <input type="text" name='firstname'  id="" value={user.firstname} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
           <label htmlFor="">Last Name</label>
           <input type="text" name='lastname'  id="" value={user.lastname} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
           <label htmlFor="">Username</label>
           <input type="text"  id="" name='username' value={user.username} onChange={handleInputChange} className='form-control'/>
       </div>    
       <div className='form-group'>
            <label htmlFor="">Password</label>
           <input type="password"  id="" name='password' value={user.password} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
            <label htmlFor="">Emailid</label>
           <input type="text"  id="" name='emailid' value={user.emailid} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
            <label htmlFor="">Mobile No</label>
           <input type="text"  id="" name='mobileno' value={user.mobileno} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
            <label htmlFor="">Specilization</label>
           <input type="text"  id="" name='specialization' value={user.specialization} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
            <label htmlFor="">Doctor Name</label>
           <input type="text"  id="" name='doctorname' value={user.doctorname} onChange={handleInputChange} className='form-control'/>
       </div>
      
       <div className='container text-center mt-3 '>
       <div className='container'>
        <strong></strong>
        </div>
           <button type='button' className='btn btn-success' onClick={createUser}>Add Doctor</button>| 
           <button type='button' className='btn btn-success' onClick={clear}>Clear</button>
       </div>
        </Fragment>
    )
}
export default CreateDoctorComponent;