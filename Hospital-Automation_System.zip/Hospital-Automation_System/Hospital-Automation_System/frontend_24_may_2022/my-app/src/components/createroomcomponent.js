import react, { Fragment, useState } from 'react';
import { Link } from 'react-router-dom';
import SelectComponent from '../reusablecomponents/selectcomponent';
import HospitalService from '../services/hospitalservice';
const CreateRoomComponent = () => {
    const [user,setRoom] = useState({roomno:0,wardid:0,roominfo:''})
    const serv = new HospitalService();
    let i = 6;
    const [message, setMessage] = useState('');
    const handleInputChange = (evt) =>{
        console.log("is it called"+evt.target.value);
        setRoom({...user,[evt.target.name]:evt.target.value});
    }
    const clear = () =>{
        setRoom({roomno:0,wardid:0,roominfo:''});
    }
    
    let n = Math.random();
    n = n * 100;

    const createRoom = () =>{
       console.log(localStorage.getItem("mytoken"));
       let mytoken = localStorage.getItem("mytoken");
        const data = {
            id:(Math.floor(n)+1),
            roomno:user.roomno,
            wardid:user.wardid,
            roominfo:user.roominfo
        }
        serv.postRoomData(data,mytoken).then(
           
            (response)=>{setMessage(`${response.data.message}`)
            alert("Room created successfully");

        }
        ).catch((error)=>{
            setMessage('Error Occured')
        });
    }
    return(
        <Fragment>
            <h1>Create Room</h1>
            <div className='form-group'>
           <label htmlFor="">RoomNo</label>
           <input type="text" name='roomno'  id="" value={user.roomno} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
           <label htmlFor="">WardID</label>
           <input type="text" name='wardid'  id="" value={user.wardid} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
           <label htmlFor="">RoomInfo</label>
           <input type="text" name='roominfo'  id="" value={user.roominfo} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='container text-center mt-3 '>
       <div className='container'>
        </div>
           <button type='button' className='btn btn-success' onClick={createRoom}>Add Room</button>|
           <button type='button' className='btn btn-success' onClick={clear}>Clear</button>
       </div>
        </Fragment>
    )
}
export default CreateRoomComponent;