import React, { Fragment, useEffect, useState } from "react";
import HospitalService from "../services/hospitalservice";
const CreatePatientComponent = () => {

    const [result,patientList] = useState([]);
    const [wardrResult,wardList] = useState([]);
    const [roomResult,roomList] = useState([]);
    const [doctorResult,doctorList] = useState([]);

    const [admit,setAdmitPatient] = useState({userid:0,wardid:0,roomid:0,status:'',disease:'',doctorid:0})
    const [message, setMessage] = useState('');
    const serv = new HospitalService();
    let n = Math.random();
    n = n * 100; 
    let randomId = (Math.floor(n)+1);
    useEffect(()=>{
        async function loadPatientData(){
            
            fetch(`http://localhost:7011/api/patients`,{
                method:'GET',
                headers:{
                    'Content-Type': 'application/json',
                }
                
            })            
            .then(resp => resp.json())
            .then(resp => patientList(resp.data))
            
        }

        async function loadWardData(){
            
            fetch(`http://localhost:7011/api/wards`,{
                method:'GET',
                headers:{
                    'Content-Type': 'application/json',
                }
                
            })            
            .then(resp => resp.json())
            .then(resp => wardList(resp.data))
            
        }
        async function loadRoomData(){
            
            fetch(`http://localhost:7011/api/rooms`,{
                method:'GET',
                headers:{
                    'Content-Type': 'application/json',
                }
                
            })            
            .then(resp => resp.json())
            .then(resp => roomList(resp.data))
            
        }
        async function loadDoctorData(){
            
            fetch(`http://localhost:7011/api/doctors`,{
                method:'GET',
                headers:{
                    'Content-Type': 'application/json',
                }
                
            })            
            .then(resp => resp.json())
            .then(resp => doctorList(resp.data))
            
        }
        loadDoctorData();
        loadRoomData();
        loadWardData();
        loadPatientData();
    },[]);

    const handleInputChange = (evt) =>{
        console.log("is it called"+evt.target.value);
        setAdmitPatient({...admit,[evt.target.name]:evt.target.value});
    }
    const clear = () =>{
        setAdmitPatient({userid:0,wardid:0,roomid:0,status:'',disease:'',doctorid:0});
    }
    const createUser = () =>{
        console.log(`result is ${admit.userid} `);
        console.log(localStorage.getItem("mytoken"));
        let mytoken = localStorage.getItem("mytoken");
         const data = {
             id:randomId,
            userid:admit.userid,
            wardid:admit.wardid,
            roomid:admit.roomid,
            status:admit.status,
            disease:admit.disease,
            doctorid:admit.doctorid
         }
         serv.postAdmitPatientData(data,mytoken).then(            
             (response)=>{setMessage(`${response.data.message}`)
            alert("Patient added successfully");
            }
         ).catch((error)=>{
             setMessage('Error Occured')
         });
     }
    return(
        <Fragment>
            <label><b>Create Patient</b></label>
            <div className="form-group">
            <div className="form-group mt-4">

                <label htmlFor="">Select Patient</label>
            <select className="form-control" name="userid" onChange={handleInputChange}>
                <option  disabled selected>---Select---</option>
                {
                    result.map((list,index) =>{
                        return(
                            <option key={index} value={list.id}>{list.firstname}</option>
                        )
                        
                    })
                   
                }
                
            </select>
            </div>
            <div className="form-group mt-4">
            <label htmlFor="">Select Ward</label>
            <select className="form-control"name="wardid" onChange={handleInputChange} >
                <option  disabled selected>---Select---</option>
                {
                    wardrResult.map((list,index) =>{
                        return(
                            <option key={index} value={list.id}>{list.wardname}</option>
                        )
                        
                    })
                   
                }
                
            </select>
            </div>
            <div className="form-group mt-4">
            <label htmlFor="">Select Room</label>
            <select className="form-control" name="roomid" onChange={handleInputChange}>
                <option  disabled selected>---Select---</option>
                {
                    roomResult.map((list,index) =>{
                        return(
                            <option key={index} value={list.id}>{list.roomno}</option>
                        )
                        
                    })
                   
                }
                
            </select>
            </div>
            <div className="form-group mt-4">
            <label htmlFor="">Select Doctor</label>
            <select className="form-control" name="doctorid" onChange={handleInputChange}>
                <option  disabled selected>---Select---</option>
                {
                    doctorResult.map((list,index) =>{
                        return(
                            <option key={index} value={list.id}>{list.doctorname}</option>
                        )
                        
                    })
                   
                }
                
            </select>
            </div>
            <div className='form-group'>
            <label htmlFor="">Disease</label>
           <input type="password"  id="" name='disease' value={admit.disease} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className="form-group mt-4">
            <label htmlFor="">Select Status</label>
            <select className="form-control" name="status" onChange={handleInputChange}>
                <option  disabled selected>---Select---</option>
                <option value="Admitted">Admited</option>
                <option value="Discharge">Discharge</option>
            </select>
            </div>
            <div className='container text-center mt-3 '>

            <button type='button' className='btn btn-success' onClick={createUser}>Admit Patient</button>| 
           <button type='button' className='btn btn-success' onClick={clear}>Clear</button> 
        </div>
        </div>
        </Fragment>
    );

}
export default CreatePatientComponent;