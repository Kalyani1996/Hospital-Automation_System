import react, { Fragment, useState } from 'react';
import { Link } from 'react-router-dom';
import SelectComponent from '../reusablecomponents/selectcomponent';
import HospitalService from '../services/hospitalservice';
const CreateUserComponent = () => {
    const [user,setUser] = useState({firstname:'',lastname:'',username:'',password:'',emailid:'',mobileno:0,roleid:0})
    const roles = [{id:3,rolename:"WardBoys"},{id:4,rolename:"Accountant"},{id:6,rolename:"Patient"}];
    const serv = new HospitalService();
    let i = 6;
    const [message, setMessage] = useState('');
    const handleInputChange = (evt) =>{
        console.log("is it called"+evt.target.value);
        setUser({...user,[evt.target.name]:evt.target.value});
    }
    const clear = () =>{
        setUser({username:'',password:''});
    }
    let n = Math.random();
    n = n * 100;
    const createUser = () =>{
       console.log(localStorage.getItem("mytoken"));
       let mytoken = localStorage.getItem("mytoken");
        const data = {
            id:(Math.floor(n)+1),
            firstname:user.firstname,
            lastname:user.lastname,
            username:user.username,
            password:user.password,
            emailid:user.emailid,
            mobileno:user.mobileno,
            roleid:user.roleid
        }
        serv.postData(data,mytoken).then(
            (response)=>{setMessage(`${response.data.message}`)
            alert("User created successfully");
        }

        ).catch((error)=>{
            setMessage('Error Occured')
        });
    }
    return(
        <Fragment>
            <h1>Create User</h1>
            <div className='form-group'>
           <label htmlFor="">First Name</label>
           <input type="text" name='firstname'  id="" value={user.firstname} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
           <label htmlFor="">Last Name</label>
           <input type="text" name='lastname'  id="" value={user.lastname} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
           <label htmlFor="">Username</label>
           <input type="text"  id="" name='username' value={user.username} onChange={handleInputChange} className='form-control'/>
       </div>    
       <div className='form-group'>
            <label htmlFor="">Password</label>
           <input type="password"  id="" name='password' value={user.password} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
            <label htmlFor="">Emailid</label>
           <input type="text"  id="" name='emailid' value={user.emailid} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
            <label htmlFor="">Mobile No</label>
           <input type="text"  id="" name='mobileno' value={user.mobileno} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
                <label>Select Role</label>
                <SelectComponent dataSource={roles} valueProperty={user.roleid}
                   getSelectedValue={(value)=>{setUser({...user, roleid:value})}}></SelectComponent>
            </div>
       <div className='container text-center mt-3 '>
       <div className='container'>
        <strong></strong>
        </div>
           <button type='button' className='btn btn-success' onClick={createUser}>Add User</button>|
           <button type='button' className='btn btn-success' onClick={clear}>Clear</button>
       </div>
        </Fragment>
    )
}
export default CreateUserComponent;